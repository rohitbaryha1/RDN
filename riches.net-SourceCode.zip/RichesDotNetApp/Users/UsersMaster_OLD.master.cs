﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RichesDotNetApp.Layer;

public partial class User_UserMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String userName = HttpContext.Current.User.Identity.Name;
        NameLabel.Text = userName;
        SSNLabel.Text = " " + new ProfileDB().getSSN(userName);

    }
}
